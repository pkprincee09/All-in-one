import { useEffect, useRef, useState } from "react";
import { RADIO_STREAM_URL } from "../config/site.js";

// status: "idle" | "loading" | "playing" | "paused" | "error"
export default function useRadio() {
  const configured = RADIO_STREAM_URL.trim().length > 0;
  const audioRef = useRef(null);
  const [status, setStatus] = useState("idle");
  const [volume, setVolume] = useState(0.8);

  useEffect(() => {
    if (!configured) return undefined;
    const audio = new Audio();
    audio.preload = "none";
    audio.volume = 0.8;
    audioRef.current = audio;
    audio.addEventListener("playing", () => setStatus("playing"));
    audio.addEventListener("pause", () => setStatus((s) => (s === "error" ? s : "paused")));
    audio.addEventListener("waiting", () => setStatus("loading"));
    audio.addEventListener("error", () => { if (audio.getAttribute("src")) setStatus("error"); });
    return () => {
      audio.pause();
      audio.removeAttribute("src");
      audioRef.current = null;
    };
  }, [configured]);

  const play = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    try {
      setStatus("loading");
      if (!audio.getAttribute("src")) audio.src = RADIO_STREAM_URL;
      await audio.play();
    } catch {
      setStatus("error");
    }
  };
  const pause = () => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.pause();
    audio.removeAttribute("src"); // live stream: stop downloading while paused
    audio.load();
    setStatus("paused");
  };
  const toggle = () => (status === "playing" || status === "loading" ? pause() : play());
  const changeVolume = (v) => {
    setVolume(v);
    if (audioRef.current) audioRef.current.volume = v;
  };

  return { configured, status, volume, toggle, changeVolume, retry: play };
}
