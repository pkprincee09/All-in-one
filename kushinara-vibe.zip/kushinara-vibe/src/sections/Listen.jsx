import Heading from "../components/Heading.jsx";
import Reveal from "../components/Reveal.jsx";
import RadioPlayer from "../components/RadioPlayer.jsx";

export default function Listen({ radio }) {
  return (
    <section id="listen" className="section wrap" aria-labelledby="listen-h">
      <Heading id="listen-h" title="Listen live">One station, mixed music, no sign-up.</Heading>
      <div className="grid-2">
        <Reveal><RadioPlayer radio={radio} /></Reveal>
        <Reveal>
          <div className="now glass" role="region" aria-label="Now playing (placeholder)">
            <h3>Now playing</h3>
            <div className="now-row">
              <div className="disc" aria-hidden="true"><i /></div>
              <div>
                <p className="now-title">KUSHINARA VIBE</p>
                <p className="muted">Your next vibe is coming up.</p>
              </div>
            </div>
            <p className="note">Placeholder text. Real track information will appear here once the live stream is connected.</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
