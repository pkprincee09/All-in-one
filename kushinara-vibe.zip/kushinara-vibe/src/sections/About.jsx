import Heading from "../components/Heading.jsx";

export default function About() {
  return (
    <section id="about" className="section wrap narrow" aria-labelledby="ab-h">
      <Heading id="ab-h" title="About KUSHINARA VIBE" />
      <p className="prose">
        KUSHINARA VIBE is a digital music and entertainment platform designed to bring mixed music, nostalgic vibes and modern listening experiences to audiences in India and around the world.
      </p>
    </section>
  );
}
