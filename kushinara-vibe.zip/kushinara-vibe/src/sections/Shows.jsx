import Heading from "../components/Heading.jsx";
import Reveal from "../components/Reveal.jsx";
import { SHOWS } from "../data/content.js";

export default function Shows() {
  return (
    <section id="shows" className="section wrap" aria-labelledby="shows-h">
      <Heading id="shows-h" title="Shows">Ideas for the schedule. Sample formats only; no hosts have been announced.</Heading>
      <Reveal>
        <ul className="shows">
          {SHOWS.map((s) => (
            <li key={s.title} className="show glass">
              <span className="tag">Coming Soon</span>
              <h3>{s.title}</h3>
              <p className="muted">{s.slot}</p>
              <p>{s.desc}</p>
            </li>
          ))}
        </ul>
      </Reveal>
    </section>
  );
}
