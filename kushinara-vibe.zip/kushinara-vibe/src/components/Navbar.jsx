import { useEffect, useState } from "react";
import { NAV_LINKS } from "../data/content.js";
import Logo from "./Logo.jsx";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <header className="nav">
      <div className="nav-inner">
        <a href="#home" aria-label="KUSHINARA VIBE home" onClick={() => setOpen(false)}>
          <Logo />
        </a>
        <nav aria-label="Main">
          <ul id="nav-list" className={"nav-list" + (open ? " open" : "")}>
            {NAV_LINKS.map((l) => (
              <li key={l.href}><a href={l.href} onClick={() => setOpen(false)}>{l.label}</a></li>
            ))}
          </ul>
        </nav>
        <button className="burger" aria-expanded={open} aria-controls="nav-list" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>
          <span /><span /><span />
        </button>
      </div>
    </header>
  );
}
