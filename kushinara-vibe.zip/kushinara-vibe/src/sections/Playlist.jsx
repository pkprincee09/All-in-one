import { useState } from "react";
import Heading from "../components/Heading.jsx";
import Reveal from "../components/Reveal.jsx";
import { YOUTUBE_PLAYLIST_ID, YOUTUBE_PLAYLIST_URL } from "../config/site.js";

export default function Playlist() {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const src = `https://www.youtube-nocookie.com/embed/videoseries?list=${YOUTUBE_PLAYLIST_ID}`;

  return (
    <section id="playlist" className="section wrap" aria-labelledby="pl-h">
      <Heading id="pl-h" title="The KUSHINARA VIBE playlist">
        Hand-picked music on YouTube. Press play and keep it running while you work, travel or relax.
      </Heading>
      <Reveal className="glass frame">
        <div className="frame-bar">
          <span className="dot-red" aria-hidden="true" />
          <span>Playlist player</span>
          <a className="link" href={YOUTUBE_PLAYLIST_URL} target="_blank" rel="noopener noreferrer">Open on YouTube</a>
        </div>
        <div className="video">
          {!loaded && !failed && (
            <button className="video-start" onClick={() => setLoaded(true)} aria-label="Load the YouTube playlist">
              <span className="play-big" aria-hidden="true">
                <svg viewBox="0 0 24 24" width="34" height="34"><path d="M7 4l13 8-13 8z" fill="currentColor" /></svg>
              </span>
              <span>Load playlist</span>
            </button>
          )}
          {loaded && !failed && (
            <iframe
              src={src}
              title="KUSHINARA VIBE YouTube playlist"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
              onError={() => setFailed(true)}
            />
          )}
          {failed && (
            <div className="video-fail">
              <p>The playlist could not load here.</p>
              <a className="btn btn-hot" href={YOUTUBE_PLAYLIST_URL} target="_blank" rel="noopener noreferrer">Open on YouTube</a>
            </div>
          )}
        </div>
        <div className="btn-row pad">
          <a className="btn btn-hot" href={YOUTUBE_PLAYLIST_URL} target="_blank" rel="noopener noreferrer">OPEN PLAYLIST</a>
        </div>
      </Reveal>
    </section>
  );
}
