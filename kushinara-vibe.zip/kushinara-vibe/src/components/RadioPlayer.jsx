import { motion, useReducedMotion } from "motion/react";
import Visualizer from "./Visualizer.jsx";

const LABELS = {
  idle: "Ready. Press play to listen.",
  loading: "Connecting to the stream...",
  playing: "Streaming live",
  paused: "Paused",
  error: "The stream could not be played. Check your connection and try again.",
};

export default function RadioPlayer({ radio }) {
  const reduce = useReducedMotion();
  const { configured, status, volume, toggle, changeVolume, retry } = radio;

  if (!configured) {
    return (
      <div className="player glass" role="region" aria-label="Live radio">
        <div className="player-head">
          <span className="badge badge-off">OFF AIR</span>
          <span className="player-name">KUSHINARA VIBE</span>
        </div>
        <Visualizer active={false} />
        <h3 className="soon">LIVE RADIO<br />Coming Soon</h3>
        <p className="muted">The live stream has not started yet. Listen to the playlist while you wait.</p>
        <a className="btn btn-ghost" href="#playlist">Go to playlist</a>
      </div>
    );
  }

  const busy = status === "loading";
  const playing = status === "playing";
  return (
    <div className="player glass" role="region" aria-label="Live radio">
      <div className="player-head">
        <span className={"badge" + (playing ? " badge-live" : " badge-off")}><i className="dot" aria-hidden="true" /> LIVE</span>
        <span className="player-name">KUSHINARA VIBE</span>
      </div>
      <Visualizer active={playing} />
      <div className="player-controls">
        <motion.button className="play" onClick={toggle} aria-label={playing || busy ? "Pause radio" : "Play radio"} whileTap={reduce ? undefined : { scale: 0.92 }}>
          {busy ? <span className="spinner" aria-hidden="true" /> : playing ? (
            <svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path d="M6 5h4v14H6zM14 5h4v14h-4z" fill="currentColor" /></svg>
          ) : (
            <svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path d="M7 4l13 8-13 8z" fill="currentColor" /></svg>
          )}
        </motion.button>
        <label className="vol">
          <span className="sr">Volume</span>
          <input type="range" min="0" max="1" step="0.01" value={volume} onChange={(e) => changeVolume(Number(e.target.value))} aria-label="Volume" />
        </label>
      </div>
      <p className={"status" + (status === "error" ? " status-err" : "")} role="status" aria-live="polite">{LABELS[status]}</p>
      {status === "error" && <button className="btn btn-ghost" onClick={retry}>Try again</button>}
    </div>
  );
}
