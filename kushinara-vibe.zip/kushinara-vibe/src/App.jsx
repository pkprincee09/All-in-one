import Navbar from "./components/Navbar.jsx";
import MiniBar from "./components/MiniBar.jsx";
import useRadio from "./hooks/useRadio.js";
import Hero from "./sections/Hero.jsx";
import Listen from "./sections/Listen.jsx";
import Playlist from "./sections/Playlist.jsx";
import Categories from "./sections/Categories.jsx";
import Nineties from "./sections/Nineties.jsx";
import Shows from "./sections/Shows.jsx";
import Request from "./sections/Request.jsx";
import Trending from "./sections/Trending.jsx";
import Share from "./sections/Share.jsx";
import About from "./sections/About.jsx";
import Contact from "./sections/Contact.jsx";
import Footer from "./sections/Footer.jsx";

export default function App() {
  const radio = useRadio();
  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <div className="grain" aria-hidden="true" />
      <Navbar />
      <main id="main">
        <Hero />
        <Listen radio={radio} />
        <Playlist />
        <Categories />
        <Nineties />
        <Shows />
        <Request />
        <Trending />
        <Share />
        <About />
        <Contact />
      </main>
      <Footer />
      <MiniBar radio={radio} />
    </>
  );
}
