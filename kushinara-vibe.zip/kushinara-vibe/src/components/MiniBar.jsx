import { WHATSAPP_REQUEST_URL } from "../config/site.js";

// Sticky bottom bar, shown on phones only (see CSS).
export default function MiniBar({ radio }) {
  const { configured, status, toggle } = radio;
  const playing = status === "playing" || status === "loading";
  return (
    <div className="minibar" role="region" aria-label="Quick actions">
      {configured ? (
        <button className="btn btn-hot" onClick={toggle}>{playing ? "Pause" : "Listen live"}</button>
      ) : (
        <a className="btn btn-ghost" href="#playlist">Playlist</a>
      )}
      <a className="btn btn-wa" href={WHATSAPP_REQUEST_URL} target="_blank" rel="noopener noreferrer">Request a song</a>
    </div>
  );
}
