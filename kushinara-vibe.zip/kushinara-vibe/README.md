# KUSHINARA VIBE

React + Vite website. 

## Run
    npm install
    npm run dev

## Build
    npm run build

## Radio stream
Open `src/config/site.js` and set `RADIO_STREAM_URL = "https://your-stream.mp3"`.

## Deploy
Push to GitHub, import the repo on vercel.com (Framework: Vite). Then update the URL in `src/config/site.js`, `index.html`, `public/robots.txt`, `public/sitemap.xml`.
