export default function Visualizer({ active, count = 24 }) {
  return (
    <div className={"viz" + (active ? " viz-on" : "")} aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <i key={i} style={{ "--i": i, "--d": ((i * 0.37) % 1.1) + "s" }} />
      ))}
    </div>
  );
}
