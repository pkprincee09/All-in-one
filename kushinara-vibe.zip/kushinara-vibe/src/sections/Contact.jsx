import Heading from "../components/Heading.jsx";
import { WHATSAPP_CONTACT_URL, WHATSAPP_NUMBER_DISPLAY } from "../config/site.js";

export default function Contact() {
  return (
    <section id="contact" className="section wrap narrow" aria-labelledby="ct-h">
      <Heading id="ct-h" title="Contact" />
      <div className="glass contact">
        <h3>KUSHINARA VIBE</h3>
        <p>WhatsApp: <a className="link" href={WHATSAPP_CONTACT_URL} target="_blank" rel="noopener noreferrer">{WHATSAPP_NUMBER_DISPLAY}</a></p>
        <a className="btn btn-wa" href={WHATSAPP_CONTACT_URL} target="_blank" rel="noopener noreferrer">CHAT ON WHATSAPP</a>
      </div>
    </section>
  );
}
