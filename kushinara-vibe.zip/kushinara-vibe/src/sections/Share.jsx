import { useState } from "react";
import Heading from "../components/Heading.jsx";
import { SITE_URL, SITE_NAME, TAGLINE } from "../config/site.js";

export default function Share() {
  const [msg, setMsg] = useState("");
  const url = window.location.origin.startsWith("http") ? window.location.origin : SITE_URL;
  const text = `${SITE_NAME} - ${TAGLINE}`;
  const enc = encodeURIComponent;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setMsg("Link copied.");
    } catch {
      window.prompt("Copy this link:", url);
      setMsg("Copy the link from the box.");
    }
  };
  const nativeShare = async () => {
    if (navigator.share) {
      try { await navigator.share({ title: SITE_NAME, text, url }); } catch { /* cancelled */ }
    } else {
      copy();
    }
  };

  return (
    <section id="share" className="section wrap" aria-labelledby="sh-h">
      <Heading id="sh-h" title="Share KUSHINARA VIBE">Know someone who loves good music? Send it their way.</Heading>
      <div className="btn-row">
        <a className="btn btn-ghost" target="_blank" rel="noopener noreferrer" href={`https://wa.me/?text=${enc(text + " " + url)}`}>WhatsApp</a>
        <a className="btn btn-ghost" target="_blank" rel="noopener noreferrer" href={`https://www.facebook.com/sharer/sharer.php?u=${enc(url)}`}>Facebook</a>
        <a className="btn btn-ghost" target="_blank" rel="noopener noreferrer" href={`https://twitter.com/intent/tweet?text=${enc(text)}&url=${enc(url)}`}>X</a>
        <button className="btn btn-ghost" onClick={copy}>Copy link</button>
        <button className="btn btn-hot" onClick={nativeShare}>Share</button>
      </div>
      <p className="status" role="status" aria-live="polite">{msg}</p>
    </section>
  );
}
