import Heading from "../components/Heading.jsx";
import Reveal from "../components/Reveal.jsx";
import Visualizer from "../components/Visualizer.jsx";

const ITEMS = [
  ["Cassette", "Flip it over, press play, and the whole side is yours."],
  ["Vinyl", "Warm crackle before the first note."],
  ["Boombox", "Big speakers, one shared room."],
  ["Headphones", "Your own private concert."],
  ["Retro radio", "Tuning the dial until the song comes in clear."],
  ["Equalizer", "Bars that rise and fall with the music."],
];

export default function Nineties() {
  return (
    <section id="nineties" className="section nineties" aria-labelledby="n-h">
      <div className="wrap">
        <Heading id="n-h" title="The 90s vibe">
          The sound of the 1990s still fills tea stalls, bus rides and living rooms. We bring that feeling to a modern player.
        </Heading>
        <Reveal>
          <div className="n-grid">
            <div className="n-art glass" aria-hidden="true">
              <div className="cassette"><i /><i /></div>
              <div className="vinyl"><b /></div>
              <Visualizer active count={20} />
            </div>
            <ul className="n-list">
              {ITEMS.map(([t, d]) => <li key={t}><h3>{t}</h3><p>{d}</p></li>)}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
