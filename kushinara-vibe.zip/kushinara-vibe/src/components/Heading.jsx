export default function Heading({ id, title, children }) {
  return (
    <div className="heading">
      <h2 id={id}>{title}</h2>
      {children && <p className="lead">{children}</p>}
    </div>
  );
}
