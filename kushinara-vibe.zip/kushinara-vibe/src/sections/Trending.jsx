import Heading from "../components/Heading.jsx";
import Reveal from "../components/Reveal.jsx";
import { DEMO_VIBES } from "../data/content.js";

export default function Trending() {
  return (
    <section id="trending" className="section wrap" aria-labelledby="tr-h">
      <Heading id="tr-h" title="Trending vibes">A preview of how discovery will look. These are sample cards, not real charts.</Heading>
      <Reveal>
        <ul className="vibes">
          {DEMO_VIBES.map((v, i) => (
            <li key={v.title} className="vibe">
              <div className="vibe-art" style={{ "--h": i * 55 + "deg" }} aria-hidden="true" />
              <div><h3>{v.title}</h3><p className="muted">{v.mood}</p></div>
              <span className="tag">{v.tag}</span>
            </li>
          ))}
        </ul>
      </Reveal>
    </section>
  );
}
