export const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "Listen", href: "#listen" },
  { label: "Playlist", href: "#playlist" },
  { label: "Music", href: "#music" },
  { label: "Shows", href: "#shows" },
  { label: "Request", href: "#request" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];
export const FOOTER_LINKS = NAV_LINKS.filter((l) => l.label !== "Shows");

export const CATEGORIES = [
  { name: "Bollywood", note: "Film songs, old and new", color: "#ffb347" },
  { name: "Punjabi", note: "Beats with bhangra energy", color: "#ff3d9a" },
  { name: "English", note: "Pop, rock and more", color: "#4da3ff" },
  { name: "Romantic", note: "Slow songs for late evenings", color: "#ff6b8b" },
  { name: "Party", note: "Loud, fast, together", color: "#8b5cff" },
  { name: "Retro", note: "Cassette-era favourites", color: "#ff8a3d" },
  { name: "Trending", note: "What people are playing now", color: "#35d4c4" },
  { name: "Chill", note: "Easy listening, low volume", color: "#7fb4ff" },
];

// Demo content only - replace with real shows later.
export const SHOWS = [
  { title: "Morning Vibe", slot: "Morning", desc: "A gentle start to the day with easy mixed music." },
  { title: "Retro Cassette Hour", slot: "Afternoon", desc: "Songs from the cassette era, one side at a time." },
  { title: "Request Night", slot: "Evening", desc: "Your WhatsApp requests, played in order." },
  { title: "Midnight Chill", slot: "Late night", desc: "Slow, soft and quiet for the last hours." },
];

// Demo content only - NOT real trending data.
export const DEMO_VIBES = [
  { title: "Sample Vibe One", mood: "Upbeat mix", tag: "Demo" },
  { title: "Sample Vibe Two", mood: "Slow and warm", tag: "Demo" },
  { title: "Sample Vibe Three", mood: "Dance floor", tag: "Demo" },
  { title: "Sample Vibe Four", mood: "Late night drive", tag: "Demo" },
];
