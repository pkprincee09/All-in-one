import Logo from "../components/Logo.jsx";
import { FOOTER_LINKS } from "../data/content.js";
import { TAGLINE } from "../config/site.js";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="wrap footer-in">
        <Logo />
        <p className="tag-line">{TAGLINE}</p>
        <nav aria-label="Footer">
          <ul className="foot-links">
            {FOOTER_LINKS.map((l) => <li key={l.href}><a href={l.href}>{l.label}</a></li>)}
          </ul>
        </nav>
        <p className="muted">© 2026 KUSHINARA VIBE. All Rights Reserved.</p>
      </div>
    </footer>
  );
}
