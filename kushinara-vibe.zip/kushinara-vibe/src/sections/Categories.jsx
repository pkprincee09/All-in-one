import Heading from "../components/Heading.jsx";
import Reveal from "../components/Reveal.jsx";
import { CATEGORIES } from "../data/content.js";

export default function Categories() {
  return (
    <section id="music" className="section wrap" aria-labelledby="music-h">
      <Heading id="music-h" title="Music for every mood">Pick a mood. Category pages will be added soon.</Heading>
      <Reveal>
        <ul className="cats">
          {CATEGORIES.map((c) => (
            <li key={c.name} className="cat" style={{ "--c": c.color }}>
              <h3>{c.name}</h3>
              <p>{c.note}</p>
            </li>
          ))}
        </ul>
      </Reveal>
    </section>
  );
}
