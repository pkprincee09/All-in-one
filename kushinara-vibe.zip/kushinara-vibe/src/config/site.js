// ============================================================
//  KUSHINARA VIBE - SETTINGS FILE (edit values here)
// ============================================================

// >>> PUT YOUR LIVE AUDIO STREAM URL BETWEEN THE QUOTES BELOW <<<
// Example: "https://your-stream-host.com/live.mp3"
// Leave empty to show "Live Radio - Coming Soon".
export const RADIO_STREAM_URL = "";

// Change this after you deploy (also update index.html, robots.txt, sitemap.xml)
export const SITE_URL = "https://kushinara-vibe.vercel.app";

export const SITE_NAME = "KUSHINARA VIBE";
export const TAGLINE = "LIVE MUSIC. REAL VIBES. ALWAYS ON.";

export const WHATSAPP_NUMBER_DISPLAY = "6394585927";
export const WHATSAPP_CONTACT_URL = "https://wa.me/916394585927";
export const WHATSAPP_REQUEST_URL =
  WHATSAPP_CONTACT_URL + "?text=" + encodeURIComponent("Hi KUSHINARA VIBE, I want to request a song.");

export const YOUTUBE_PLAYLIST_ID = "PLMRKdK25AuPVjHl9Kdb-gkBy0Cm7Zi2xo";
export const YOUTUBE_PLAYLIST_URL = "https://youtube.com/playlist?list=" + YOUTUBE_PLAYLIST_ID;
