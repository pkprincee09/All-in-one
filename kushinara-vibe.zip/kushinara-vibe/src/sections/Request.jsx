import Reveal from "../components/Reveal.jsx";
import { WHATSAPP_REQUEST_URL } from "../config/site.js";

export default function Request() {
  return (
    <section id="request" className="section wrap" aria-labelledby="req-h">
      <Reveal className="cta glass">
        <h2 id="req-h">WHAT SHOULD WE PLAY NEXT?</h2>
        <p>Send your song request directly to KUSHINARA VIBE.</p>
        <a className="btn btn-wa btn-xl" href={WHATSAPP_REQUEST_URL} target="_blank" rel="noopener noreferrer">REQUEST ON WHATSAPP</a>
      </Reveal>
    </section>
  );
}
