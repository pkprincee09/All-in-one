import { useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import heroLg from "../assets/hero-lg.webp";
import heroSm from "../assets/hero-sm.webp";
import { WHATSAPP_REQUEST_URL } from "../config/site.js";

export default function Hero() {
  const reduce = useReducedMotion();
  const [imgFailed, setImgFailed] = useState(false);
  const enter = (i) =>
    reduce ? {} : { initial: { opacity: 0, y: 22 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.6, delay: 0.1 + i * 0.12, ease: "easeOut" } };

  return (
    <section id="home" className="hero" aria-labelledby="hero-title">
      {!imgFailed && (
        <img
          className="hero-img"
          src={heroLg}
          srcSet={`${heroSm} 900w, ${heroLg} 1672w`}
          sizes="100vw"
          width="1672"
          height="941"
          alt="KUSHINARA VIBE poster: a 1990s desk with a boombox, cassettes, vinyl records and headphones, with a night view of Kushinagar"
          fetchpriority="high"
          decoding="async"
          onError={() => setImgFailed(true)}
        />
      )}
      <div className="hero-shade" aria-hidden="true" />
      <div className="wrap hero-content">
        <motion.p className="chip" {...enter(0)}>90s INSPIRED • GLOBAL VIBES</motion.p>
        <motion.h1 id="hero-title" {...enter(1)}>
          YOUR VIBE.<br />YOUR MUSIC.<br /><span className="grad">YOUR RADIO.</span>
        </motion.h1>
        <motion.p className="hero-sub" {...enter(2)}>
          Experience mixed music, nostalgic vibes and modern entertainment with KUSHINARA VIBE.
        </motion.p>
        <motion.div className="btn-row" {...enter(3)}>
          <a className="btn btn-hot" href="#listen">LISTEN NOW</a>
          <a className="btn btn-wa" href={WHATSAPP_REQUEST_URL} target="_blank" rel="noopener noreferrer">REQUEST A SONG</a>
        </motion.div>
        <div className="hero-wave" aria-hidden="true">
          {Array.from({ length: 40 }, (_, i) => <i key={i} style={{ "--i": i, "--d": ((i * 0.23) % 1.2) + "s" }} />)}
        </div>
      </div>
    </section>
  );
}
