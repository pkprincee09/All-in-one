export default function Logo() {
  return (
    <span className="logo">
      <span className="logo-top">KUSHINARA</span>
      <span className="logo-bot">VIBE</span>
    </span>
  );
}
